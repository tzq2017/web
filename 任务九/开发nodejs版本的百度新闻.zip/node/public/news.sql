-- phpMyAdmin SQL Dump
-- version 4.4.15.5
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1:3306
-- Generation Time: 2017-05-24 07:34:53
-- 服务器版本： 5.6.34-log
-- PHP Version: 7.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `baidunews`
--

-- --------------------------------------------------------

--
-- 表的结构 `news`
--

CREATE TABLE IF NOT EXISTS `news` (
  `id` int(11) NOT NULL,
  `newstype` char(200) NOT NULL,
  `newstitle` varchar(200) NOT NULL,
  `newsimg` varchar(200) NOT NULL,
  `newstime` datetime NOT NULL,
  `newssrc` char(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `news`
--

INSERT INTO `news` (`id`, `newstype`, `newstitle`, `newsimg`, `newstime`, `newssrc`) VALUES
(1, '精选', '测试数据库中的第一条数据', 'img/news2.JPEG', '2017-05-19 00:00:00', '极客学院'),
(2, '百家', '123', 'img/news1.jpg', '2017-05-18 00:00:00', 'jike'),
(3, '图片', '456', 'img/news2.JPEG', '2017-05-18 00:00:00', 'jikexueyuan'),
(4, '娱乐', '789', 'img/news1.jpg', '2017-05-20 00:00:00', 'jikexueyuan'),
(5, '本地', 'bendi', 'img/news1.jpg', '2017-05-20 00:00:00', 'jikexueyuan'),
(6, '社会', 'shehui', 'img/news2.JPEG', '2017-05-20 00:00:00', 'jikexueyuan'),
(7, '军事', 'junshi', 'img/news1.jpg', '2017-05-20 00:00:00', 'jikexueyuan'),
(8, '女人', 'nvren', 'img/news2.JPEG', '2017-05-20 00:00:00', 'jikexueyuan'),
(9, '搞笑', 'gaoxiao', 'img/news1.jpg', '2017-05-20 00:00:00', 'jikexueyuan'),
(10, '互联网', 'internet', 'img/news1.jpg', '2017-05-20 00:00:00', 'jikexueyuan'),
(11, '精选', '211', 'img/news1.jpg', '2017-05-22 00:00:00', 'test');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
