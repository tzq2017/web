//更多产品右侧下拉
$(document).ready(function(){
	$(".more").mouseover(function(){
		$(".div4").show();
	});
	$(".div4").mouseleave(function(){
		$(".div4").hide();
	});
});

//Tab切换
$(document).ready(function(){
	$(".sp6a").click(function(){
		$(".title_content").show();
	});
	$(".div6b11").click(function(){
		$("#content_1").show();
	})
});


//使用单例模式改善
//使用单例模式，最重要的作用就是把所有相关的东西定义为对象的属性，
//然后通过render，bind，init等key值对应的function进行绑定等等；
//使用单例模式的好处就是，一个对象只有一个实例，这样写也使代码看起来更加清晰有条理；

//更多产品右侧下拉
 var obj={
 	init: function(){
 		this.render();
 		this.bind();
 	},
 	render: function(){
 		this.class = $(".more");
 	},
 	bind: function(){
 		this.class.mouseover(function(){
 			$(".div4").show();
 		})
 	}
 }

  var obj={
 	init: function(){
 		this.render();
 		this.bind();
 	},
 	render: function(){
 		this.class = $(".div4");
 	},
 	bind: function(){
 		this.class.mouseleave(function(){
 			$(".div4").hide();
 		})
 	}
 }

 //Tab切换
  var obj={
 	init: function(){
 		this.render();
 		this.bind();
 	},
 	render: function(){
 		this.class = $(".sp6a");
 	},
 	bind: function(){
 		this.class.click(function(){
 			$(".title_content").show();
 		})
 	}
 }

   var obj={
 	init: function(){
 		this.render();
 		this.bind();
 	},
 	render: function(){
 		this.class = $(".div6b11");
 	},
 	bind: function(){
 		this.id.click(function(){
 			$("#content_1").show();
 		})
 	}
 }