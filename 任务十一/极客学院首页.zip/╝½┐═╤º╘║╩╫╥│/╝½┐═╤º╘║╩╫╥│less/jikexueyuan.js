/*头部导航栏二维码显示/隐藏*/
$(document).ready(function(){
	$(".app-icon").mouseover(function(){
		$(".submenu").fadeIn();
	});
	$(".app-icon").mouseleave(function(){
		$(".submenu").hide();
	});
});
/*头部导航栏二维码显示/隐藏 end*/
/*头部账号设置显示/隐藏*/
$(document).ready(function(){
	$(".login-icon").mouseover(function(){
		$(".submenu2").fadeIn();
	});
	$(".login-icon").mouseleave(function(){
		$(".submenu2").hide();
	});
});
/*头部账号设置显示/隐藏 end*/
/*searchbox内容显示/隐藏*/
$(document).ready(function(){
	$(".search-icon").click(function(){
		$(".searchbox").animate({width:'toggle'},"slow");
	});
	$(".close-icon").click(function(){
		$(".searchbox").hide();
	});
});
/*searchbox内容显示/隐藏 end*/
/*list 中js效果*/
$(document).ready(function () {
    var changeId = $("#changeid"),
        ul = changeId.children("ul"),
        li = ul.children("li");
    li.mouseenter(function () {
        var that = $(this),
            lesPlay = that.find(".lessonplay"),
            lesInfor = that.children(".lesson-infor"),
            lesInforP = lesInfor.children("p"),
            lesIconBox = that.find(".lessonicon-box"),
            zhongJi = that.find(".zhongji"),
            learnNumber = that.find(".learn-number");
        lesPlay.fadeTo("slow", 1);
        lesInfor.animate({
            height: '175px'
        });
        lesIconBox.animate({
            bottom: '-2px'
        });
        lesInforP.slideDown();
        zhongJi.slideDown();
        lesIconBox.slideDown();
        learnNumber.show();
    });

    li.mouseleave(function () {
        var that = $(this),
            lesPlay = that.find(".lessonplay"),
            lesInfor = that.children(".lesson-infor"),
            lesInforP = lesInfor.children("p"),
            lesIconBox = that.find(".lessonicon-box"),
            zhongJi = that.find(".zhongji"),
            learnNumber = that.find(".learn-number");
        lesPlay.fadeTo("slow", 0);
        lesInfor.animate({
            height: '88px'
        });
        lesIconBox.animate({
            bottom: '4px'
        });
        lesInforP.slideUp();
        zhongJi.slideUp();
        learnNumber.hide();
    });
});
/*list 中js效果 end*/
